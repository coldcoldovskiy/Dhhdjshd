(function () {
    'use strict';

    /* =========================================================
       TYPE CONFIG — placeholder, hint, validation, mask
       ========================================================= */
    var TYPES = {
        phone: { name: 'Телефон',
            placeholder: 'Введите номер телефона...',
            hint: 'Формат: +7 (999) 123-45-67',
            mask: 'phone',
            validate: function (v) {
                var d = v.replace(/[^0-9]/g, '');
                return d.length >= 10 && d.length <= 15
                    ? null : 'Введите корректный номер (10–15 цифр)';
            }
        },
        email: { name: 'Email',
            placeholder: 'Введите email...',
            hint: 'Формат: user@example.com',
            validate: function (v) {
                return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)
                    ? null : 'Введите корректный email';
            }
        },
        vk: { name: 'VK',
            placeholder: 'Введите ID, ссылку или username VK...',
            hint: 'Например: id123456, durov или vk.com/durov',
            validate: function (v) { return v.length >= 2 ? null : 'Слишком короткий запрос'; }
        },
        fio: { name: 'ФИО',
            placeholder: 'Введите Фамилию Имя Отчество...',
            hint: 'Например: Иванов Иван Иванович',
            validate: function (v) {
                return v.trim().split(/\s+/).length >= 2
                    ? null : 'Введите минимум фамилию и имя';
            }
        },
        inn: { name: 'ИНН',
            placeholder: 'Введите ИНН...',
            hint: '10 цифр (юр.лицо) или 12 цифр (физ.лицо)',
            mask: 'inn',
            validate: function (v) {
                var d = v.replace(/[^0-9]/g, '');
                return (d.length === 10 || d.length === 12)
                    ? null : 'ИНН содержит 10 или 12 цифр';
            }
        },
        snils: { name: 'СНИЛС',
            placeholder: 'Введите СНИЛС...',
            hint: 'Формат: 112-233-445 95 (11 цифр)',
            mask: 'snils',
            validate: function (v) {
                var d = v.replace(/[^0-9]/g, '');
                return d.length === 11 ? null : 'СНИЛС содержит 11 цифр';
            }
        },
        ip: { name: 'IP-адрес',
            placeholder: 'Введите IP-адрес...',
            hint: 'Например: 192.168.0.1',
            validate: function (v) {
                return /^(\d{1,3}\.){3}\d{1,3}$/.test(v.trim())
                    ? null : 'Введите корректный IPv4-адрес';
            }
        },
        car: { name: 'Авто (госномер)',
            placeholder: 'Введите гос. номер...',
            hint: 'Например: А123ВС777',
            validate: function (v) { return v.length >= 5 ? null : 'Слишком короткий номер'; }
        },
        nick: { name: 'Никнейм',
            placeholder: 'Введите никнейм / username...',
            hint: 'Поиск по нику в соцсетях и базах',
            validate: function (v) { return v.length >= 2 ? null : 'Слишком короткий ник'; }
        },
        auto: { name: 'Авто (VIN)',
            placeholder: 'Введите VIN или гос. номер...',
            hint: 'VIN (17 символов) или гос. номер',
            validate: function (v) { return v.length >= 5 ? null : 'Слишком короткий запрос'; }
        }
    };

    /* =========================================================
       ICONS
       ========================================================= */
    function svg(body) {
        return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
            'stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
            body + '</svg>';
    }
    var ICONS = {
        phone: svg('<rect x="6" y="2.5" width="12" height="19" rx="2.5"/><line x1="10.5" y1="18.5" x2="13.5" y2="18.5"/>'),
        email: svg('<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="M4 7.5l8 5.5 8-5.5"/>'),
        vk: svg('<path d="M21 11.5a8.5 8.5 0 0 1-12.6 7.4L3 21l2.1-5.4A8.5 8.5 0 1 1 21 11.5z"/>'),
        fio: svg('<circle cx="12" cy="8" r="3.5"/><path d="M5 20c0-3.9 3.1-7 7-7s7 3.1 7 7"/>'),
        inn: svg('<path d="M3 9l9-5 9 5"/><path d="M5 9.5V20h14V9.5"/><line x1="9" y1="13" x2="9" y2="17"/><line x1="12" y1="13" x2="12" y2="17"/><line x1="15" y1="13" x2="15" y2="17"/><line x1="3" y1="20" x2="21" y2="20"/>'),
        snils: svg('<rect x="3" y="5" width="18" height="14" rx="2.5"/><circle cx="8" cy="10.5" r="2"/><path d="M5 16c0-1.7 1.3-3 3-3s3 1.3 3 3"/><line x1="14" y1="9.5" x2="18" y2="9.5"/><line x1="14" y1="13" x2="18" y2="13"/>'),
        ip: svg('<circle cx="12" cy="12" r="9"/><line x1="3" y1="12" x2="21" y2="12"/><path d="M12 3a14 14 0 0 1 0 18 14 14 0 0 1 0-18z"/>'),
        car: svg('<path d="M3 13l2-5.5A2 2 0 0 1 6.9 6h10.2a2 2 0 0 1 1.9 1.5L21 13"/><path d="M3 13h18v4a1 1 0 0 1-1 1h-1.4a1 1 0 0 1-1-1v-1H6.4v1a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z"/><circle cx="7" cy="15.4" r="0.7"/><circle cx="17" cy="15.4" r="0.7"/>'),
        nick: svg('<circle cx="12" cy="12" r="4"/><path d="M16 12v1.5a2.5 2.5 0 0 0 5 0V12a9 9 0 1 0-3.4 7.1"/>'),
        auto: svg('<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/><line x1="8.5" y1="13" x2="15.5" y2="13"/><line x1="8.5" y1="16.5" x2="13" y2="16.5"/>'),
        search: svg('<circle cx="11" cy="11" r="7"/><line x1="16.2" y1="16.2" x2="21" y2="21"/>'),
        info: svg('<circle cx="12" cy="12" r="9"/><line x1="12" y1="11" x2="12" y2="16"/><circle cx="12" cy="7.8" r="0.6"/>'),
        close: svg('<line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/>'),
        check: svg('<polyline points="20 6 9 17 4 12"/>'),
        moon: svg('<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>'),
        trash: svg('<polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>'),
        alert: svg('<circle cx="12" cy="12" r="9"/><line x1="12" y1="8" x2="12" y2="12"/><circle cx="12" cy="16" r="0.8" fill="currentColor" stroke="none"/>')
    };
    function typeIcon(t) { return ICONS[t] || ICONS.search; }

    var activeType = null;
    var lastRaw = '';
    var HISTORY_KEY = 'astra_history';
    var HISTORY_MAX = 8;
    var THEME_KEY = 'astra_theme';

    /* =========================================================
       THEME
       ========================================================= */
    function initTheme() {
        var saved = localStorage.getItem(THEME_KEY);
        var prefersLight = window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches;
        var theme = saved || (prefersLight ? 'light' : 'dark');
        setTheme(theme);
        document.getElementById('themeToggle').addEventListener('click', function () {
            var current = document.documentElement.getAttribute('data-theme');
            var next = current === 'light' ? 'dark' : 'light';
            setTheme(next);
            vibrate(10);
        });
    }

    function setTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem(THEME_KEY, theme);
        var icon = document.getElementById('themeIcon');
        if (theme === 'light') {
            icon.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>';
        } else {
            icon.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg>';
        }
    }

    /* =========================================================
       VIBRATE
       ========================================================= */
    function vibrate(ms) {
        if (navigator.vibrate && typeof navigator.vibrate === 'function') {
            try { navigator.vibrate(ms || 15); } catch (e) {}
        }
    }

    /* =========================================================
       TOAST NOTIFICATIONS
       ========================================================= */
    function showToast(message, type) {
        type = type || 'info';
        var container = document.getElementById('toastContainer');
        var toast = document.createElement('div');
        toast.className = 'toast toast--' + type;

        var iconSvg = ICONS.check;
        if (type === 'error') iconSvg = ICONS.alert;
        else if (type === 'info') iconSvg = ICONS.info;

        toast.innerHTML = '<span class="toast-icon">' + iconSvg + '</span><span>' + escapeHtml(message) + '</span>';
        container.appendChild(toast);

        setTimeout(function () {
            toast.classList.add('toast-out');
            setTimeout(function () { toast.remove(); }, 350);
        }, 2200);
    }

    /* =========================================================
       SPLASH SCREEN — star draws, flashes, then text reveals
       ========================================================= */
    function runSplash() {
        var splash = document.getElementById('splash');
        var star = document.getElementById('splashStar');
        var target = document.getElementById('splashText');
        var caret = document.getElementById('caret');

        // Step 1: animate star drawing
        star.classList.add('animate');

        // Step 2: flash the star after draw completes
        setTimeout(function () {
            star.classList.add('flash');
            vibrate([20, 30, 20]);
        }, 800);

        // Step 3: reveal text
        setTimeout(function () {
            target.textContent = 'astra';
            target.classList.add('show');
        }, 1100);

        // Step 4: finish
        setTimeout(function () {
            if (caret) caret.classList.add('hide');
            splash.classList.add('fade-out');
            setTimeout(function () {
                splash.classList.add('hidden');
                var app = document.getElementById('app');
                app.classList.remove('hidden');
                requestAnimationFrame(function () { app.classList.add('show'); });
            }, 700);
        }, 2200);
    }

    /* =========================================================
       HISTORY — localStorage + chips
       ========================================================= */
    function loadHistory() {
        try {
            var raw = localStorage.getItem(HISTORY_KEY);
            return raw ? JSON.parse(raw) : [];
        } catch (e) { return []; }
    }

    function saveHistory(history) {
        try {
            localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(0, HISTORY_MAX)));
        } catch (e) {}
    }

    function addHistory(type, query) {
        var history = loadHistory();
        // remove duplicates
        history = history.filter(function (h) { return !(h.type === type && h.query === query); });
        history.unshift({ type: type, query: query, time: Date.now() });
        saveHistory(history);
    }

    function renderHistoryChips() {
        var container = document.getElementById('historyChips');
        var row = document.getElementById('historyRow');
        var history = loadHistory().filter(function (h) { return h.type === activeType; });

        if (!history.length) {
            row.classList.add('hidden');
            return;
        }

        container.innerHTML = '';
        history.slice(0, 6).forEach(function (h) {
            var chip = document.createElement('div');
            chip.className = 'history-chip';
            chip.title = h.query;
            chip.innerHTML = '<span class="hc-query">' + escapeHtml(h.query) + '</span>' +
                '<span class="hc-remove" title="Удалить">' + ICONS.close + '</span>';

            chip.addEventListener('click', function (e) {
                if (e.target.closest('.hc-remove')) {
                    e.stopPropagation();
                    removeHistory(h.type, h.query);
                    renderHistoryChips();
                    vibrate(8);
                    return;
                }
                document.getElementById('searchInput').value = h.query;
                vibrate(10);
            });
            container.appendChild(chip);
        });

        row.classList.remove('hidden');
    }

    function removeHistory(type, query) {
        var history = loadHistory().filter(function (h) {
            return !(h.type === type && h.query === query);
        });
        saveHistory(history);
    }

    /* =========================================================
       INPUT MASKS
       ========================================================= */
    function applyMask(input, type) {
        var maskType = TYPES[type] && TYPES[type].mask;
        if (!maskType) return function () {};

        var handler = function () {
            var val = input.value;
            var sel = input.selectionStart;
            var beforeLen = val.length;

            if (maskType === 'phone') {
                var digits = val.replace(/[^0-9]/g, '');
                if (digits.startsWith('7') || digits.startsWith('8')) {
                    digits = digits.substring(1);
                }
                digits = digits.substring(0, 10);
                var formatted = '+7';
                if (digits.length > 0) {
                    formatted += ' (' + digits.substring(0, 3);
                    if (digits.length >= 3) formatted += ')';
                    if (digits.length > 3) formatted += ' ' + digits.substring(3, 6);
                    if (digits.length > 6) formatted += '-' + digits.substring(6, 8);
                    if (digits.length > 8) formatted += '-' + digits.substring(8, 10);
                }
                input.value = formatted;
            } else if (maskType === 'snils') {
                var d = val.replace(/[^0-9]/g, '').substring(0, 11);
                var out = '';
                if (d.length > 0) out += d.substring(0, 3);
                if (d.length > 3) out += '-' + d.substring(3, 6);
                if (d.length > 6) out += '-' + d.substring(6, 9);
                if (d.length > 9) out += ' ' + d.substring(9, 11);
                input.value = out;
            } else if (maskType === 'inn') {
                var inn = val.replace(/[^0-9]/g, '').substring(0, 12);
                input.value = inn;
            }

            // adjust cursor
            var afterLen = input.value.length;
            var diff = afterLen - beforeLen;
            if (diff > 0 && sel !== null) {
                input.setSelectionRange(sel + diff, sel + diff);
            }
        };

        input.addEventListener('input', handler);
        return function () { input.removeEventListener('input', handler); };
    }

    /* =========================================================
       STEP FLOW
       ========================================================= */
    var currentMaskCleanup = null;

    function selectType(t) {
        activeType = t;
        var cfg = TYPES[t];

        // step indicator
        document.getElementById('step1').removeAttribute('data-active');
        document.getElementById('step2').setAttribute('data-active', 'true');

        // swap panels
        var typePanel = document.getElementById('typePanel');
        var queryPanel = document.getElementById('queryPanel');
        typePanel.classList.add('hidden');
        queryPanel.classList.remove('hidden');
        queryPanel.classList.remove('panel-pop');
        void queryPanel.offsetWidth;
        queryPanel.classList.add('panel-pop');

        // selected chip
        document.getElementById('chipIcon').innerHTML = typeIcon(activeType);
        document.getElementById('chipName').textContent = cfg.name;

        // CLEAR input + set type-specific placeholder/hint
        var input = document.getElementById('searchInput');
        input.value = '';
        input.placeholder = cfg.placeholder;
        document.getElementById('inputHint').textContent = cfg.hint;
        hideError();
        clearResults();

        // remove old mask, apply new
        if (currentMaskCleanup) { currentMaskCleanup(); currentMaskCleanup = null; }
        currentMaskCleanup = applyMask(input, t);

        // show history chips
        renderHistoryChips();

        setTimeout(function () { input.focus(); }, 120);
    }

    function resetToTypes() {
        activeType = null;
        document.getElementById('step2').removeAttribute('data-active');
        document.getElementById('step1').setAttribute('data-active', 'true');
        document.getElementById('queryPanel').classList.add('hidden');
        var tp = document.getElementById('typePanel');
        tp.classList.remove('hidden');
        tp.classList.remove('panel-pop');
        void tp.offsetWidth;
        tp.classList.add('panel-pop');
        document.getElementById('searchInput').value = '';
        hideError();
        clearResults();
        document.querySelectorAll('.type-btn').forEach(function (b) { b.classList.remove('active'); });
        if (currentMaskCleanup) { currentMaskCleanup(); currentMaskCleanup = null; }
    }

    function clearResults() {
        var r = document.getElementById('results');
        r.classList.add('hidden');
        r.innerHTML = '';
    }

    /* =========================================================
       SETUP
       ========================================================= */
    function setup() {
        initTheme();

        document.querySelectorAll('.type-btn').forEach(function (b) {
            var t = b.getAttribute('data-type');
            b.innerHTML = '<span class="ti">' + typeIcon(t) + '</span>' +
                '<span class="tl">' + b.textContent.trim() + '</span>';
            b.addEventListener('click', function () {
                vibrate(15);
                document.querySelectorAll('.type-btn').forEach(function (x) { x.classList.remove('active'); });
                b.classList.add('active');
                selectType(t);
            });
        });

        var chipClear = document.getElementById('chipClear');
        chipClear.innerHTML = ICONS.close;
        chipClear.addEventListener('click', resetToTypes);
        document.getElementById('searchBtn').addEventListener('click', function () {
            vibrate([10, 20]);
            doSearch();
        });
        document.getElementById('searchInput').addEventListener('keydown', function (e) {
            if (e.key === 'Enter') {
                vibrate([10, 20]);
                doSearch();
            }
        });
        document.getElementById('searchInput').addEventListener('input', hideError);

        document.getElementById('aboutBtn').addEventListener('click', function () {
            document.getElementById('about').classList.remove('hidden');
            document.getElementById('typePanel').classList.add('hidden');
        });
        document.getElementById('aboutClose').addEventListener('click', function () {
            document.getElementById('about').classList.add('hidden');
            if (!activeType) document.getElementById('typePanel').classList.remove('hidden');
        });
    }

    /* =========================================================
       VALIDATION + ERROR
       ========================================================= */
    function showError(msg) {
        var el = document.getElementById('inputError');
        el.textContent = '⚠ ' + msg;
        el.classList.remove('hidden');
        var input = document.getElementById('searchInput');
        input.classList.remove('shake');
        void input.offsetWidth;
        input.classList.add('shake');
    }
    function hideError() {
        document.getElementById('inputError').classList.add('hidden');
    }

    function extractApiError(data, httpStatus) {
        if (httpStatus === 429) return 'Слишком много запросов. Попробуйте позже.';
        if (httpStatus === 401 || httpStatus === 403) return 'Ошибка авторизации API (ключ отклонён).';
        if (httpStatus >= 500 && httpStatus < 600 && httpStatus !== 599) return 'Сервер источника недоступен (HTTP ' + httpStatus + ').';
        if (httpStatus === 599) return 'Нет соединения с сервером. Проверьте интернет.';

        if (!data || typeof data !== 'object') return null;
        if (data.error === true || data.error === 'true' || data.success === false || data.status === 'error') {
            return cleanMsg(data.message || data.error_message || data.detail || data.msg || 'Неизвестная ошибка API');
        }
        if (typeof data.error === 'string' && data.error.length) return cleanMsg(data.error);
        return null;
    }

    function cleanMsg(m) {
        m = String(m).trim();
        var low = m.toLowerCase();
        if (low.indexOf('not found') !== -1 || low.indexOf('no result') !== -1 || low.indexOf('нет данных') !== -1) {
            return null;
        }
        return m;
    }

    function isEmptyResult(data) {
        if (!data || typeof data !== 'object') return true;
        var fast = data.fast_result || data.fastResult;
        var full = data.full_result || data.fullResult || data.result;
        if (hasContent(fast) || hasContent(full)) return false;
        if (data.results_count === 0 || data.count === 0) return true;
        var g = pickGeneric(data);
        return !hasContent(g);
    }

    /* =========================================================
       SEARCH
       ========================================================= */
    function doSearch() {
        if (!activeType) return;
        var input = document.getElementById('searchInput');
        var q = input.value.trim();
        var cfg = TYPES[activeType];

        if (!q) { showError('Введите запрос'); input.focus(); return; }
        var vErr = cfg.validate ? cfg.validate(q) : null;
        if (vErr) { showError(vErr); input.focus(); return; }

        // Save to history
        addHistory(activeType, q);

        hideError();
        clearResults();
        document.getElementById('loading').classList.remove('hidden');

        fetch('/api/search?search=' + encodeURIComponent(q), { headers: { 'Accept': 'application/json' } })
            .then(function (res) { return res.text().then(function (t) { return { status: res.status, text: t }; }); })
            .then(function (resp) {
                document.getElementById('loading').classList.add('hidden');
                lastRaw = resp.text;
                var data;
                try { data = JSON.parse(resp.text); } catch (e) { data = null; }

                var apiErr = extractApiError(data, resp.status);
                if (apiErr) { renderError(apiErr); return; }
                if (data === null) { renderError('Некорректный ответ сервера.'); return; }
                if (isEmptyResult(data)) { renderEmpty(q); return; }

                renderResults(data);
            })
            .catch(function (err) {
                document.getElementById('loading').classList.add('hidden');
                lastRaw = JSON.stringify({ error: true, message: String(err) });
                renderError('Сетевая ошибка: ' + String(err));
                showToast('Ошибка сети', 'error');
            });
    }

    /* =========================================================
       RENDER STATES
       ========================================================= */
    function renderError(msg) {
        var r = document.getElementById('results');
        r.innerHTML = '';
        r.classList.remove('hidden');
        var c = document.createElement('div');
        c.className = 'error-card';
        c.innerHTML = '<div class="err-title">Ошибка</div><div class="err-msg"></div>';
        c.querySelector('.err-msg').textContent = msg;
        r.appendChild(c);
        var retry = document.createElement('button');
        retry.className = 'link-btn';
        retry.textContent = 'Повторить';
        retry.addEventListener('click', doSearch);
        r.appendChild(retry);
        r.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function renderEmpty(q) {
        var r = document.getElementById('results');
        r.innerHTML = '';
        r.classList.remove('hidden');
        var c = document.createElement('div');
        c.className = 'empty-card';
        c.innerHTML = '<div class="empty-icon"></div><div>По запросу <b></b> ничего не найдено</div>';
        c.querySelector('.empty-icon').innerHTML = ICONS.search;
        c.querySelector('b').textContent = q;
        r.appendChild(c);
        r.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function renderResults(data) {
        var r = document.getElementById('results');
        r.innerHTML = '';
        r.classList.remove('hidden');

        var head = document.createElement('div');
        head.className = 'result-head';
        var detected = document.createElement('div');
        detected.className = 'detected';
        var dtype = data.detected_type || data.type || activeType || 'unknown';
        detected.innerHTML = '<span class="icon">' + typeIcon(dtype) + '</span><span>Тип: <span class="dtype"></span></span>';
        detected.querySelector('.dtype').textContent = String(dtype);
        head.appendChild(detected);

        var copyBtn = document.createElement('button');
        copyBtn.className = 'copy-btn';
        copyBtn.textContent = 'COPY JSON';
        copyBtn.addEventListener('click', function () { copyJson(); });
        head.appendChild(copyBtn);
        r.appendChild(head);

        var stats = buildStats(data);
        if (stats) r.appendChild(stats);

        var fast = data.fast_result || data.fastResult;
        if (fast && hasContent(fast)) {
            r.appendChild(sectionTitle('Быстрый результат'));
            r.appendChild(renderFast(fast));
        }

        var full = data.full_result || data.fullResult || data.result;
        if (full && hasContent(full)) renderFull(full, r);

        if (!fast && !full) {
            var generic = pickGeneric(data);
            if (generic && hasContent(generic)) {
                r.appendChild(sectionTitle('Результат'));
                r.appendChild(renderFast(generic));
            }
        }

        var imgs = collectImages(data);
        if (imgs.length) {
            r.appendChild(sectionTitle('Медиа'));
            var wrap = document.createElement('div');
            wrap.className = 'media-preview';
            imgs.slice(0, 12).forEach(function (src) {
                var im = document.createElement('img');
                im.src = src; im.loading = 'lazy'; im.referrerPolicy = 'no-referrer';
                im.onerror = function () { im.remove(); };
                wrap.appendChild(im);
            });
            r.appendChild(wrap);
        }

        appendRaw(r);
        r.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    /* =========================================================
       ANIMATED COUNTER
       ========================================================= */
    function animateCounter(el, target, duration) {
        target = parseFloat(target) || 0;
        duration = duration || 800;
        var start = performance.now();
        var from = 0;
        var isFloat = target % 1 !== 0;

        function update(now) {
            var elapsed = now - start;
            var progress = Math.min(elapsed / duration, 1);
            // easeOutCubic
            var eased = 1 - Math.pow(1 - progress, 3);
            var current = from + (target - from) * eased;
            el.textContent = isFloat ? current.toFixed(2) : Math.round(current);
            if (progress < 1) requestAnimationFrame(update);
        }
        requestAnimationFrame(update);
    }

    /* =========================================================
       RENDER PARTS
       ========================================================= */
    function buildStats(data) {
        var items = [];
        if (data.results_count != null) items.push(['результатов', data.results_count]);
        if (data.sources_count != null) items.push(['источников', data.sources_count]);
        if (data.search_time != null) items.push(['время', data.search_time]);
        if (data.count != null && data.results_count == null) items.push(['count', data.count]);
        if (!items.length) return null;

        var row = document.createElement('div');
        row.className = 'stats';
        items.forEach(function (it) {
            var s = document.createElement('div');
            s.className = 'stat';
            s.innerHTML = it[0] + ': <b>0</b>';
            var b = s.querySelector('b');
            b.textContent = '0';
            row.appendChild(s);
            // animate after append
            requestAnimationFrame(function () {
                animateCounter(b, it[1], 900);
            });
        });
        return row;
    }

    function renderFast(obj) {
        var grid = document.createElement('div');
        grid.className = 'kv-grid';
        flattenPairs(obj).forEach(function (pair, idx) {
            var card = document.createElement('div');
            card.className = 'kv-card';
            card.style.animationDelay = (idx * 0.03) + 's';
            var k = document.createElement('div');
            k.className = 'kv-key'; k.textContent = pair[0];
            var v = document.createElement('div');
            v.className = 'kv-val'; v.innerHTML = valToHtml(pair[1]);
            card.appendChild(k); card.appendChild(v);

            // click to copy
            card.addEventListener('click', function () {
                var text = String(pair[1]);
                copyText(text, function () {
                    card.classList.add('copied-flash');
                    setTimeout(function () { card.classList.remove('copied-flash'); }, 400);
                });
            });

            grid.appendChild(card);
        });
        return grid;
    }

    function renderFull(full, container) {
        var base = {}, dbs = [];
        if (Array.isArray(full)) {
            full.forEach(function (rec) { dbs.push(rec); });
        } else if (typeof full === 'object') {
            Object.keys(full).forEach(function (key) {
                var val = full[key];
                if (Array.isArray(val)) val.forEach(function (rec) { dbs.push(wrapRecord(key, rec)); });
                else if (val && typeof val === 'object') dbs.push(wrapRecord(key, val));
                else base[key] = val;
            });
        }
        if (hasContent(base)) {
            container.appendChild(sectionTitle('Базовая информация'));
            container.appendChild(renderFast(base));
        }
        if (dbs.length) {
            container.appendChild(sectionTitle('Базы данных'));
            dbs.forEach(function (rec, idx) { container.appendChild(renderRecord(rec, idx)); });
        }
    }

    function wrapRecord(source, rec) {
        if (rec && typeof rec === 'object' && !Array.isArray(rec)) {
            var clone = {};
            clone.__source = rec.__source || rec.source || rec.database || rec.db || source;
            Object.keys(rec).forEach(function (k) { clone[k] = rec[k]; });
            return clone;
        }
        return { __source: source, value: rec };
    }

    function renderRecord(rec, idx) {
        var box = document.createElement('div');
        box.className = 'record';
        box.style.animationDelay = (idx * 0.04) + 's';
        var src = rec.__source || rec.source || rec.database || rec.db || ('запись #' + (idx + 1));
        var title = document.createElement('div');
        title.className = 'record-source'; title.textContent = String(src);
        box.appendChild(title);

        var pairs = flattenPairs(rec).filter(function (p) {
            return p[0] !== '__source' && p[0] !== 'source';
        });

        pairs.forEach(function (pair) {
            var line = document.createElement('div');
            line.className = 'record-line';
            var rk = document.createElement('span'); rk.className = 'rk'; rk.textContent = pair[0];
            var rv = document.createElement('span'); rv.className = 'rv'; rv.innerHTML = valToHtml(pair[1]);
            line.appendChild(rk); line.appendChild(rv);
            box.appendChild(line);

            // click to copy the value
            line.addEventListener('click', function (e) {
                // don't copy if clicking a link
                if (e.target.tagName === 'A') return;
                var text = String(pair[1]);
                copyText(text, function () {
                    line.classList.add('copied-flash');
                    setTimeout(function () { line.classList.remove('copied-flash'); }, 400);
                });
            });
        });

        return box;
    }

    /* =========================================================
       COPY HELPERS
       ========================================================= */
    function copyText(text, onDone) {
        var done = function () {
            showToast('Скопировано!', 'success');
            vibrate(10);
            if (onDone) onDone();
        };
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(done).catch(function () { fallbackCopy(text, done); });
        } else {
            fallbackCopy(text, done);
        }
    }

    function copyJson() {
        var text = lastRaw || '';
        copyText(text, function () {
            showToast('JSON скопирован', 'success');
        });
    }

    function fallbackCopy(text, done) {
        var ta = document.createElement('textarea');
        ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
        document.body.appendChild(ta); ta.select();
        try { document.execCommand('copy'); } catch (e) {}
        document.body.removeChild(ta);
        if (done) done();
    }

    /* =========================================================
       HELPERS
       ========================================================= */
    function pickGeneric(data) {
        var skip = { detected_type: 1, type: 1, results_count: 1, sources_count: 1,
            search_time: 1, count: 1, status: 1, key: 1, search: 1, success: 1, error: 1 };
        var out = {};
        Object.keys(data).forEach(function (k) { if (!skip[k]) out[k] = data[k]; });
        return out;
    }

    function flattenPairs(obj, prefix) {
        var out = [];
        if (obj == null) return out;
        if (typeof obj !== 'object') { out.push([prefix || 'value', obj]); return out; }
        Object.keys(obj).forEach(function (k) {
            if (k === '__source') return;
            var val = obj[k];
            var label = prefix ? prefix + '.' + k : k;
            if (val && typeof val === 'object') {
                if (Array.isArray(val) && val.every(isScalar)) out.push([label, val.join(', ')]);
                else flattenPairs(val, label).forEach(function (p) { out.push(p); });
            } else out.push([label, val]);
        });
        return out;
    }

    function isScalar(v) {
        return v == null || typeof v === 'string' || typeof v === 'number' || typeof v === 'boolean';
    }
    function hasContent(obj) {
        if (obj == null) return false;
        if (Array.isArray(obj)) return obj.length > 0;
        if (typeof obj === 'object') return Object.keys(obj).length > 0;
        return String(obj).length > 0;
    }
    function valToHtml(v) {
        if (v == null) return '<span class="muted">—</span>';
        var s = String(v);
        if (/^https?:\/\//i.test(s)) return '<a href="' + escapeAttr(s) + '" target="_blank" rel="noreferrer">' + escapeHtml(s) + '</a>';
        return escapeHtml(s);
    }
    function collectImages(data) {
        var urls = [];
        (function walk(node) {
            if (node == null) return;
            if (typeof node === 'string') {
                if (/^https?:\/\/\S+\.(png|jpe?g|gif|webp|bmp)(\?\S*)?$/i.test(node)) urls.push(node);
                return;
            }
            if (Array.isArray(node)) { node.forEach(walk); return; }
            if (typeof node === 'object') {
                Object.keys(node).forEach(function (k) {
                    var v = node[k];
                    if (typeof v === 'string' && /(photo|avatar|image|img|picture|foto)/i.test(k) && /^https?:\/\//i.test(v)) urls.push(v);
                    else walk(v);
                });
            }
        })(data);
        return Array.from(new Set(urls));
    }
    function sectionTitle(text) {
        var t = document.createElement('div');
        t.className = 'section-title'; t.textContent = text;
        return t;
    }
    function appendRaw(container) {
        if (!lastRaw) return;
        var wrap = document.createElement('details');
        wrap.className = 'raw-wrap';
        var sum = document.createElement('summary');
        sum.textContent = 'Сырой JSON';
        wrap.appendChild(sum);
        var pre = document.createElement('pre');
        pre.className = 'raw-json';
        var pretty = lastRaw;
        try { pretty = JSON.stringify(JSON.parse(lastRaw), null, 2); } catch (e) {}
        pre.textContent = pretty;
        wrap.appendChild(pre);
        container.appendChild(wrap);
    }
    function escapeHtml(s) {
        return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }
    function escapeAttr(s) { return escapeHtml(s).replace(/'/g, '&#39;'); }

    /* =========================================================
       BOOT
       ========================================================= */
    document.addEventListener('DOMContentLoaded', function () {
        runSplash();
        setup();
    });
})();
